# NBODY SIMULADOR
	Simula un grupo de particulas 