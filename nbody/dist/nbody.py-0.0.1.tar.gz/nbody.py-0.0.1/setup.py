from setuptools import find_packages, setup

setup(
    name='nbody.py',
    version='0.0.1',
    description='Modulo de simulación para n-cuerpos',
    author='Javier Urrutia',
    packages=find_packages(),
    )